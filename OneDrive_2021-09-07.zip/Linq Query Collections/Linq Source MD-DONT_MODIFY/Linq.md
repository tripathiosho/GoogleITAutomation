
## <h1> LINQ Query  Collections

The query collection is categorized into multiple sections,

### <h2>  Collection Filtering   </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| To Filter Int Array and return collection | `Int Array:  '{ 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 }'` | Return int array | Int[]          | `int[] outputArray = (from num in numbers where num < 5 select num);`                                                 | numbers is the input Array |
| Multiple Condition Filtering              | Any Collection                                 | Return int array | Any Collection | `List<Product> products = (from prod in products where prod.UnitsInStock > 0 && prod.UnitPrice > 3.00  select prod);` | Returns collections        |
| Single Condition with string as filter    | Any Collection                                 | Return int array | Any Collection | `List<Product> products = (from cust in customers here cust.Region == "WA" select cust);`                             | Returns collections        |
| Single Condition with string as filter    | ``var input = new string[] { "policy1", "ironman", "spiderman", "star", "test" };``   | Return int array | Any Collection | `var res = from word in words        where word.Contains('man')          select word;`                             | Returns collections        |


### <h2> DataTable Filtering  </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| To Filter Data Row from DataTable based on single condition | DataTable | Return DataRow   | DataRow or Further logic builds   | `var drRow = (From row In dt.Select() Where row("Name").ToString.StartsWith("Policy") Select row);`                            | numbers is the input Array                                  |
| To Filter Data Row based on identity column                 | DataTable | Return DataRow   | DataRow or Further logic builds   | `var results = (from DataRow myRow in myDataTable.Rows  where (int)myRow["RowNo"] == 1  select myRow);`                        | numbers is the input Array                                  |
| Filter with string not null or empty                        | DataTable | Return DataTable | DataTable or Further logic builds | `DataTable filteredrows = dt.AsEnumerable.Where(Function(x) String.IsNullOrEmpty(x(“Type”).ToString.Trim)).CopyToDataTable();` | dt is the input DataTable, Type is the column for filtering |
| Filter Datatable with Distinct Policy Numbers                        | DataTable | Int[] or Any further Build logic  | DataTable or Further logic builds | `int[] IdList = (((From dr As DataRow In dtExceldata Select Convert.ToInt32(dr("PolicyNumbers"))).ToArray()).Distinct()).ToArray()` | IdList is the input DataTable |
| Two Datatables with same structure, Find differences                        | DataTable | Any further Build logic  | DataTable or Further logic builds | `Datarow[] dtRows = dtPolicy1.AsEnumerable().Where(Function(row) Not dtPolicy2.AsEnumerable().Where(function(r) r("PolicyNumber").ToString.Equals(row("PolicyNumber").ToString) and r("TotalAmount").ToString.Equals(row("TotalAmount").ToString)).Any).ToArray; Datatable dt = resultDT_Rows.CopyToDataTable` | dtRows is the input DataTable, PolicyNumber,TotalAmount is the column for filtering between these 2 datatables. |
| From Datatable (Datacolumn) filter numeric values only                        | DataTable | Any further Build logic  | DataTable or Further logic builds | `var intonly = dtInput.AsEnumerable().Where(x=>Regex.IsMatch(x.Field<string>("Policy Number"), @"^\d{1,}$")).ToList();` | numbersonly gives you the list from that logic can be split |
| From Datatable (Datacolumn) filter non - numeric values only                        | DataTable | Any further Build logic  | DataTable or Further logic builds | `var nonintonly = dtInput.AsEnumerable().Except(intonly).ToList();` | refer intonly above query and this resultset is nonintonly.  |
| Trim all the DataColumns in the datatable                        | DataTable | DataTable  | DataTable or Further logic builds | `dtDataTable.AsEnumerable().ToList().ForEach(row =>{ var colList = row.ItemArray.ToList();row.ItemArray = colList.Select(y => y.ToString().Trim()).ToArray(); })` | refer intonly above query and this resultset is nonintonly.  |


### <h2> Conversions </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| Convert JSON to DataTable                   | JSON      | Return DataTable | DataTable or Further logic builds | `DataTable dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));`                       | JSON converted to DataTable                                                     |
| Change one Column in DataTable to Uppercase | DataTable | Return DataTable | DataTable                         | `dt.AsEnumerable().ToList().ForEach(p => p.SetField<string>("Name", (p.Field<string>("Name").ToUpper())));` | Converts entire one column to Upper case, Here name is column name in Datatable |

### <h2> Multiple DataTable Filtering </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| Join Multiple DataTable & Merge to One                   | Multiple DataTable      | Return Single DataTable | DataTable  |``` Code Block Below this section``` | Multiple Datatable Join converted to DataTable   |

```
Console.WriteLine("Code Start linq, This final output of this datatable is left join so all the values which are not matched will be empty. For Inner join needs remove the line from into and null condition.");

var result = (from inputmapping in dtInput.AsEnumerable() 
	                join divMapping in dtDiv.AsEnumerable() on inputmapping.Field<string>("Division") equals divMapping.Field<string>("div_nm") into dtDivi from divMapping in dtDivi.DefaultIfEmpty()
	                join depMapping in dtDep.AsEnumerable() on inputmapping.Field<string>("Department") equals depMapping.Field<string>("dept_nm") into dtDept from depMapping in dtDept.DefaultIfEmpty()
	                join workEventMapping in dtWorkEve.AsEnumerable() on inputmapping.Field<string>("Work Event Name") equals workEventMapping.Field<string>("evnt_nm") into dtEC from workEventMapping in dtEC.DefaultIfEmpty()
	                join priorityMapping in dtPriorityCode.AsEnumerable() on inputmapping.Field<string>("Priority") equals priorityMapping.Field<string>("priority_Name") into dtPC from priorityMapping in dtPC.DefaultIfEmpty()
	                join serviceChannelMapping in dtServiceChannel.AsEnumerable() on inputmapping.Field<string>("Service Channel") equals serviceChannelMapping.Field<string>("service_channel_name") into dtSC from serviceChannelMapping in dtSC.DefaultIfEmpty()
	                select new
                    {
				    	CategoryType =  inputmapping["Category Type"],
				        CategoryField = inputmapping["Category Field"],
				        AdminSystem = inputmapping["Admin System"],
				        Division = (divMapping == null ? "" :  divMapping["div_cde"]),
						Department = (depMapping == null ? "" : depMapping["dept_cde"]),
						WorkEventName = (workEventMapping == null ? "" : workEventMapping["evnt_nr"]),
						ReceivedDate           =  String.IsNullOrEmpty(inputmapping["Received Date"].ToString()) ? DateTime.Now.ToString("MM/dd/yyyy") : inputmapping["Received Date"].ToString(),
						FollowUpDate           = inputmapping["Follow Up Date"],
						Priority           = (priorityMapping == null ? "" : priorityMapping["priority_Name"]),
						AssignTo           =  String.IsNullOrEmpty(inputmapping["Assign To"].ToString()) ? "" : inputmapping["Assign To"].ToString().Replace("Agency Assign: ",""),
						ServiceChannel           = (serviceChannelMapping == null ? "" : serviceChannelMapping["service_channel_no"]),
						CashAmount           = inputmapping["Cash Amount"],
						Requestor           =  "Other",
						RequestorName           = inputmapping["Requestor Name"],
						PhoneNumber           = inputmapping["Phone Number"],
						RequestingAgency           = inputmapping["Requesting Agency"],
						State           = inputmapping["State"],
						ActualEventDate           = String.IsNullOrEmpty(inputmapping["Actual Event Date"].ToString()) ? DateTime.Now.ToString("MM/dd/yyyy") : inputmapping["Actual Event Date"],
						InGoodOrderNIGOStatus           = String.IsNullOrEmpty(inputmapping["In Good Order/NIGO Status"].ToString()) ? "None" : inputmapping["In Good Order/NIGO Status"].ToString() ,
						ShortComment           = inputmapping["Short Comment"],
						ExtendedComments           = inputmapping["Extended Comments"],
						ActionforEvent           = inputmapping["Action for Event"],
						ErrorResult =    (inputmapping["Category Field"].ToString().Length <=0) ? "True" : "False",
						ExcelFileName = inputmapping["ExcelFileName"],
						ExcelRowNo = inputmapping["ExcelRowNo"]
			         });

Console.WriteLine("Code Start linq looping");

foreach(var rowinfo in result)
{
	dtOutput.Rows.Add(rowinfo.CategoryType,
	                                rowinfo.CategoryField,
	                                rowinfo.AdminSystem,
	                                rowinfo.Division,
	                                rowinfo.Department,
	                                rowinfo.WorkEventName,
									rowinfo.ReceivedDate,
									rowinfo.FollowUpDate,
									rowinfo.Priority,
									rowinfo.AssignTo,
									rowinfo.ServiceChannel,
									rowinfo.CashAmount,
									rowinfo.Requestor,
									rowinfo.RequestorName,
									rowinfo.PhoneNumber,
									rowinfo.RequestingAgency,
									rowinfo.State,
									rowinfo.ActualEventDate,
									rowinfo.InGoodOrderNIGOStatus,
									rowinfo.ShortComment,
									rowinfo.ExtendedComments,
									rowinfo.ActionforEvent,
	                                rowinfo.ErrorResult,
	                                rowinfo.ExcelFileName,
	                                rowinfo.ExcelRowNo
	);
}

Console.WriteLine("Final DataTable Extracted and it worked...");
```


### <h2> JSON Filtering </h2>

JSON is the Key / Value pair combination.

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| All the columns values from JSON based on key from JSON    | JSON  | Return specific value collections based on Key name filter in JSON | Based on logic | `IEnumerable<JToken> arrJToken= = (from c in jArrayObject select c("name"));`                                          | Return All the values from JSON based on Input key name provided. |
| All values from JSON which starts with specific characters | JSON  | Based on logic                                                     | Based on logic | `IEnumerable<JToken> arrJToken= = ((from country in jArrayObject Where country("name").ToString.StartsWith("A")));`    | Return All the values from JSON values from specificied keys.     |
| All values from JSON which contains                        | JSON  | Based on logic                                                     | Based on logic | `IEnumerable<JToken> arrJToken= = ((from country in jArrayObject Where country("name").ToString.Contains("Policy")));` | Return All the values from JSON values from specificied keys.     |

### <h2> JSON Path Filtering </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| Filter only one string from JSON Path based on multiple conditions | JSONPath Value | Based on logic | Based on logic | `IEnumerable<JToken> arrJToken=jObjectResponse.SelectTokens("$.agreements[?(@.agreementKeyAdmin=='VNTGKC')].agreementCustomers[?(@.roleType=='OWNR' && @.roleSubType=='LIST')].fullName");`             | We can get all the matching names from this query. |      |
| Filter only one string from JSON Path based on multiple conditions | JSONPath Value | String         | Based on logic | `string singleStringoutput=jObjectResponse.SelectTokens("$.agreements[?(@.agreementKeyAdmin=='VNTGKC')].agreementCustomers[?(@.roleType=='OWNR' && @.roleSubType=='LIST')].fullName")FirstOrDefault();` | We can get all the matching names from this query. | **** |

### <h2> String Filtering </h2>

| Use Case                                  | Input                                          | Output           | Return Type    | Query                                                                                                                 | Note                       | Minimum Record data set allowed | Maximum Record data set allowed
|-------------------------------------------|------------------------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|----------------------------|
| Check String is Alphanumeric | String | Bool   | Further Based on logic | `string str ="ABC123"; if (str.All(char.IsLetterOrDigit)) { Console.WriteLine("Alphanumeric String");}else {Console.WriteLine("Non-Alphanumeric String");}` | Returns bool on string is alphanumeric |
| Multiple String Replacement | String | String   | Output as Single String replaced with needed expressions | Code Below section | Output will be final string.

 ```
            string inputStr = "body1body2body3";
            var replaceStr = new Dictionary<string, string> { { "1", "#" }, { "2", "##" }, { "3", "###" } };
            string output = replaceStr.Aggregate(inputStr, (current, replacement) => current.Replace(replacement.Key, replacement.Value)).ToString();
```
