Please leverage the Linq Query collections shared,
- The PDF & HTML both are same content only difference is file format.
- Whichever is comfortable for your query search please use it.

For any Feature Requests / Further additions:
- Feature Requests : Please place your requirements with Input if any in this same folder.
  Every week we will try to update all the requests to main Linq (PDF,HTML) files.
- Any LINQ Query additions please place it in the same excel separate sheets as Queries to be added
  All the changes will be updated weekly and published to the team Mlist.

For any urgent needs, Please connect with Ganesh Ramakrishnan